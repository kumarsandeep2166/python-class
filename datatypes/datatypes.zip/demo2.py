lst = [45,78,12.36, 'python', 'java', 'a', 10-6j, 'php', 'dotnet', 12,35,76]
print(lst)
print(lst[0:6])
print(lst[0:10:2])
print(lst[0::3])
lst[8] = "class"
print(lst)
print(lst*2)
print(lst[-2])
print(lst[-8:-1])
print(lst[-10:-1:2])