a=None
print(a) # None
print(type(a)) # <class 'NoneType'>

# comments in python
# single line comment
# comments are basically used to Demonstrate  the logic which is applied for development
# mulitiline comment
# docstrings
# multiline cmment and dcostrings both are same
# multiline comments are defined by triple quotes starting and ending

"""this is a python class
and we are learning python in good manner."""

# comments are not executed by the compiler but it occupies memory inside PVM[python virtual machine]

str = """this is a python class
and we are learning python in good manner."""

# docstrings are nothing but a variable holds multiple lines 
# here "str" is called as docstring


