d = {1:'a', 2:'b', 3:'c', 4:'d'}
print(d[1])
print(d[2])
print(d[3])